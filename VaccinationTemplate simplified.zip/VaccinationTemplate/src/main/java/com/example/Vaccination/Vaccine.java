package com.example.Vaccination;

public interface Vaccine {
        
/** This method returns the name of vaccine in String format 
    For example:  "Covid". 
**/        
        String getType();
}
