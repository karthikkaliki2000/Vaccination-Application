package com.example.Vaccination;

import java.util.Scanner;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@SpringBootApplication
public class VaccinationApplication {
	static ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
	static String name = null;
	static int age = 0;
	static User user=null;
	static String appointmentDate = null;
	static String appointmentTime = null;
	static String appointmentLocation = null;
	static String beanId = null;
	static Scanner s;
	public static void main(String[] args) {
		s=new Scanner(System.in);
	       System.out.println("Welcome to the Vaccination Application");
	       while(true) {
	    	   System.out.println("Please choose your vacchine preference:\n1.Covid\n2.Polio\n3.Typhoid");
	          int vaccinePreference=s.nextInt();
	          switch(vaccinePreference) {
	          case 1:{
	        	  fun();
	        	  break;
	     		}
	          case 2:{
	        	  fun();
	        	  break;
	          }
	          case 3:{
	        	  fun();
	        	  break;
	          }
	          }
	          }
	       }
	private static void fun() {
		// TODO Auto-generated method stub
		  System.out.println("Whom do you want to vaccinate\n1.Father\n2.Mother\n3.Self\n4.Spouse\n5.Exit");
   		int choice=s.nextInt();
   		switch(choice) {
	   		case 1:{
	   			beanId="covidFather";
	   			help(beanId);
	   			break;
	   		}
	   		case 2:{
	   			beanId="covidMother";
	   			help(beanId);
	   			break;		   		}
	   		case 3:{
	   			beanId="covidSelf";
	   			help(beanId);
	   			break;
	   		}
	   		case 4:{
	   			beanId="covidSpouse";
	   			help(beanId);
	   			break;
	   		}
	   		case 5:{
	   			
	   			System.exit(0);
	   		}
	   		}
	   		
		
	}
	private static void help(String beanId) {
		// TODO Auto-generated method stub
		user=(User)context.getBean(beanId);
			if(user.IsVaccinated()) {
				System.out.println("User is already Vaccinated");
			}
			else {
			System.out.println("Please enter "+user.getClass().getSimpleName()+" details:");
			System.out.println("Name:");
			name=s.next();
			System.out.println("Age:");
			age=s.nextInt();
			
			System.out.println("Appointment date (YYYY-MM-DD):");
			s.nextLine();
			appointmentDate=s.nextLine();
			
			System.out.println("Appointment time (HH-MM AM/PM):");
			appointmentTime=s.nextLine();
			System.out.println("Appointment location:");
			appointmentLocation=s.nextLine();
		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
	    
     t.setDetails(appointmentTime, appointmentLocation, appointmentDate);

     user.setUserDetails(name, age, t);
    
     user.setAppointment();
			}
		
	}
	}

//    public static void main(String[] args) {
//    	   ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
//    	String name = null;
//    	int age = 0;
//    	User user=null;
//    	String appointmentDate = null;
//    	String appointmentTime = null;
//    	String appointmentLocation = null;
//    	String beanId = null;
//    	Scanner s=new Scanner(System.in);
//       System.out.println("Welcome to the Vaccination Application");
//      while(true) {
//    	  System.out.println("Please choose your vacchine preference:\n1.Covid\n2.Polio\n3.Typhoid");
//          int vaccinePreference=s.nextInt();
//          switch (vaccinePreference) {
//   	case 1: {
//   		System.out.println("Whom do you want to vaccinate\n1.Father\n2.Mother\n3.Self\n4.Spouse\n5.Exit");
//   		int choice=s.nextInt();
//   		
//   		switch(choice) {
//   		case 1:{
//   			beanId="covidFather";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Father details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 2:{
//   			beanId="covidMother";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Mother details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 3:{
//   			beanId="covidSelf";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Self details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 4:{
//   			beanId="covidSpouse";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Spouse details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 5:{
//   			break;
//   		}
//   		}
//   		break;
//   	}
//   	case 2: {
//   		System.out.println("Whom do you want to vaccinate\n1.Father\n2.Mother\n3.Self\n4.Spouse\n5.Exit");
//   		int choice=s.nextInt();
//   		
//   		switch(choice) {
//   		case 1:{
//   			beanId="polioFather";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Father details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 2:{
//   			beanId="polioMother";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Mother details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 3:{
//   			beanId="polioSelf";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Self details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 4:{
//   			beanId="polioSpouse";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Spouse details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 5:{
//   			break;
//   		}
//   		}
//
//   		break;
//   	}
//   	case 3: {
//   		System.out.println("Whom do you want to vaccinate\n1.Father\n2.Mother\n3.Self\n4.Spouse\n5.Exit");
//   		int choice=s.nextInt();
//   		
//   		switch(choice) {
//   		case 1:{
//   			beanId="typhoidFather";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Father details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 2:{
//   			beanId="typhoidMother";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Mother details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 3:{
//   			beanId="typhoidSelf";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Self details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 4:{
//   			beanId="typhoidSpouse";
//   			user=(User)context.getBean(beanId);
//   			if(user.IsVaccinated()) {
//   				System.out.println("User is already Vaccinated");
//   			}
//   			else {
//   			System.out.println("Please enter Spouse details:");
//   			System.out.println("Name:");
//   			name=s.next();
//   			System.out.println("Age:");
//   			age=s.nextInt();
//   			
//   			System.out.println("Appointment date (YYYY-MM-DD):");
//   			s.nextLine();
//   			appointmentDate=s.nextLine();
//   			
//   			System.out.println("Appointment time (HH-MM AM/PM):");
//   			appointmentTime=s.nextLine();
//   			System.out.println("Appointment location:");
//   			appointmentLocation=s.nextLine();
//   		 TimeAndLocation t=(TimeAndLocation)context.getBean("timeAndLocation");
//   	    
//         t.setDetails(appointmentTime, appointmentLocation, appointmentDate);
//
//         user.setUserDetails(name, age, t);
//        
//         user.setAppointment();
//   			}
//   			break;
//   		}
//   		case 5:{
//   			break;
//   		}
//   		}
//
//   		break;
//   	}
//   	default:
//   		
//   	}
//     
//       
//      
//      System.out.println("Do you want to register for someone Else\n1. Yes\n2. No");
//      int yesorno=s.nextInt();
//      switch(yesorno) {
//      case 2:{
//   	   return;
//      }
//      }
//      }
//    
//     
//
//    }

